// async function fetchArtworks() {
//     try {
//       const response = await fetch('/api/artworks'); 
//       const data = await response.json();
//       return data;
//     } catch (error) {
//       console.error('Error fetching artworks:', error);
//       throw new Error('Failed to fetch artworks');
//     }
//   }
  
//   async function fetchWorkshops() {
//     try {
//       const response = await fetch('/api/workshops'); 
//       const data = await response.json();
//       return data;
//     } catch (error) {
//       console.error('Error fetching workshops:', error);
//       throw new Error('Failed to fetch workshops');
//     }
//   }
  